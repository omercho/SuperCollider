QuNeo by Jonathan Siemasko - Email: schemawound@yahoo.com - Web: http://schemawound.com/

In order to get started with the QuNeo quark:
1) Run the QuNeo Editor software.
2) Click one of the controls to activate the menus.
3) Use the preset dropdown to pick the QuNeo preset you wish to overwrite.
4) File-> Import Preset.
5) Navigate to \QuNeo\QuNeoPresets\BasicSC_QuNeo.quneopreset within your Supercollider extentions directory.
6) Click "Save Preset"
7) Click "Update Preset"
8) Run \QuNeo\QuNeoPresets\BasicSC_QuNeo.scd code from within Supercollider.  I recommend adding it to your startup file.
9) Try the examples in the QuNeo help file.