                       The Global Airport Database
                         Release Version 0.0.1

Author: Arash Partow 2003
Copyright notice:
Free use of The Global Airport Database is permitted under the guidelines
and in accordance with the most current version of the Common Public License.
http://www.opensource.org/licenses/cpl.php


Introduction


The Global Airport Database is a FREE online downloadable database of aiports
big and small from around the world. The database is presented in a simple
token seperated format.


For more information please visit:

http://www.partow.net/miscellaneous/airportdatabase/index.html
